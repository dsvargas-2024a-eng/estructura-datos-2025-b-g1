public class Triangulo implements Figura {
    private double lado1;
    private double lado2;
    private double lado3;
    private String color;

    public Triangulo(double lado1, double lado2, double lado3, String color) {
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
        this.color = color;
    }

    @Override
    public double calcularPerimetro() {
        return lado1 + lado2 + lado3;
    }

    @Override
    public double calcularArea() {
        double s = calcularPerimetro() / 2.0;
        double areaSq = s * (s - lado1) * (s - lado2) * (s - lado3);
        if (areaSq <= 0) return 0;
        return Math.sqrt(areaSq);
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("----- TRIÁNGULO -----");
        System.out.printf("Color: %s%n", color);
        System.out.printf("Lados: %.2f, %.2f, %.2f%n", lado1, lado2, lado3);
        System.out.printf("Área: %.4f%n", calcularArea());
        System.out.printf("Perímetro: %.4f%n", calcularPerimetro());
        System.out.println();
    }
}
