public class Circulo implements Figura {
    private double radio;
    private String color;

    public Circulo(double radio, String color) {
        this.radio = radio;
        this.color = color;
    }

    @Override
    public double calcularArea() {
        return Math.PI * radio * radio;
    }

    @Override
    public double calcularPerimetro() {
        return 2 * Math.PI * radio;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("----- CÍRCULO -----");
        System.out.printf("Color: %s%n", color);
        System.out.printf("Radio: %.2f%n", radio);
        System.out.printf("Área: %.4f%n", calcularArea());
        System.out.printf("Perímetro: %.4f%n", calcularPerimetro());
        System.out.println();
    }
}
