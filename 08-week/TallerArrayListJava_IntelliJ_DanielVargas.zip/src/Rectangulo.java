public class Rectangulo implements Figura {
    private double base;
    private double altura;
    private String color;

    public Rectangulo(double base, double altura, String color) {
        this.base = base;
        this.altura = altura;
        this.color = color;
    }

    @Override
    public double calcularArea() {
        return base * altura;
    }

    @Override
    public double calcularPerimetro() {
        return 2 * (base + altura);
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("---- RECTÁNGULO ----");
        System.out.printf("Color: %s%n", color);
        System.out.printf("Base: %.2f, Altura: %.2f%n", base, altura);
        System.out.printf("Área: %.4f%n", calcularArea());
        System.out.printf("Perímetro: %.4f%n", calcularPerimetro());
        System.out.println();
    }
}
