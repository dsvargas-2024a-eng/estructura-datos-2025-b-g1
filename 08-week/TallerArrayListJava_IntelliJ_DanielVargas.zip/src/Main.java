import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Figura> figuras = new ArrayList<>();

        figuras.add(new Circulo(3.0, "Rojo"));
        figuras.add(new Circulo(5.5, "Azul"));
        figuras.add(new Rectangulo(4.0, 2.5, "Verde"));
        figuras.add(new Rectangulo(6.0, 3.0, "Amarillo"));
        figuras.add(new Triangulo(3.0, 4.0, 5.0, "Naranja"));
        figuras.add(new Triangulo(5.0, 5.0, 6.0, "Violeta"));

        System.out.println("=== INFORMACIÓN DE FIGURAS ===\n");
        for (Figura f : figuras) {
            f.mostrarInformacion();
        }

        double areaTotal = 0;
        double perimetroTotal = 0;
        for (Figura f : figuras) {
            areaTotal += f.calcularArea();
            perimetroTotal += f.calcularPerimetro();
        }

        System.out.println("=== RESUMEN ===");
        System.out.printf("Número de figuras: %d%n", figuras.size());
        System.out.printf("Área total: %.4f%n", areaTotal);
        System.out.printf("Perímetro total: %.4f%n", perimetroTotal);
    }
}
