# 📘 Taller ArrayList con Java — Informe (Daniel Vargas)

## 🎯 Objetivo
Aplicar el uso de la colección `ArrayList` en Java para almacenar y manipular objetos creados a partir de clases que representan figuras geométricas. Cada clase debe tener atributos propios y métodos que permitan calcular área, perímetro y mostrar información general de la figura. Se busca reforzar el manejo de colecciones junto con la Programación Orientada a Objetos.

## 📋 Actividades desarrolladas
1. Se creó la clase **Circulo** con atributos `radio` y `color` y métodos para calcular área, perímetro y mostrar información.  
2. Se creó la clase **Rectangulo** con atributos `base`, `altura` y `color`. Implementa los métodos para calcular área, perímetro e imprimir datos.  
3. Se creó la clase **Triangulo** con atributos `lado1`, `lado2`, `lado3` y `color`. Se utilizó la fórmula de Herón para el cálculo de su área.  
4. En la clase **Main**, se creó un `ArrayList<Figura>` donde se insertaron al menos dos objetos de cada clase y se imprimió la información de todas las figuras junto con un resumen de áreas y perímetros.  

## 📂 Código fuente
El código fuente se encuentra en la carpeta `src/` con las clases:  
- `Figura.java`  
- `Circulo.java`  
- `Rectangulo.java`  
- `Triangulo.java`  
- `Main.java`  

## 📸 Evidencia de ejecución
```
=== INFORMACIÓN DE FIGURAS ===

----- CÍRCULO -----
Color: Rojo
Radio: 3.00
Área: 28.2743
Perímetro: 18.8496

----- CÍRCULO -----
Color: Azul
Radio: 5.50
Área: 95.0332
Perímetro: 34.5575

---- RECTÁNGULO ----
Color: Verde
Base: 4.00, Altura: 2.50
Área: 10.0000
Perímetro: 13.0000

---- RECTÁNGULO ----
Color: Amarillo
Base: 6.00, Altura: 3.00
Área: 18.0000
Perímetro: 18.0000

----- TRIÁNGULO -----
Color: Naranja
Lados: 3.00, 4.00, 5.00
Área: 6.0000
Perímetro: 12.0000

----- TRIÁNGULO -----
Color: Violeta
Lados: 5.00, 5.00, 6.00
Área: 12.0000
Perímetro: 16.0000

=== RESUMEN ===
Número de figuras: 6
Área total: 169.3075
Perímetro total: 112.4071
```

## ✅ Conclusión
El taller permitió practicar la implementación de clases en Java aplicando los principios de **POO** junto con el uso de colecciones dinámicas (`ArrayList`). Se evidenció cómo almacenar objetos de diferentes tipos bajo una misma interfaz, calcular propiedades geométricas y presentar la información en consola.
