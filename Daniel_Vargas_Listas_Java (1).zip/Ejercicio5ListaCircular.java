class NodoCircular {
    int dato;
    NodoCircular siguiente;

    NodoCircular(int dato) {
        this.dato = dato;
        this.siguiente = this;
    }
}

class ListaCircular {
    private NodoCircular cabeza = null;

    public void insertar(int dato) {
        NodoCircular nuevo = new NodoCircular(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoCircular temp = cabeza;
            while (temp.siguiente != cabeza) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevo;
            nuevo.siguiente = cabeza;
        }
    }

    public void eliminar(int dato) {
        if (cabeza == null) return;
        NodoCircular temp = cabeza, previo = null;
        do {
            if (temp.dato == dato) {
                if (previo != null) {
                    previo.siguiente = temp.siguiente;
                } else {
                    NodoCircular ultimo = cabeza;
                    while (ultimo.siguiente != cabeza) ultimo = ultimo.siguiente;
                    cabeza = cabeza.siguiente;
                    ultimo.siguiente = cabeza;
                }
                return;
            }
            previo = temp;
            temp = temp.siguiente;
        } while (temp != cabeza);
    }

    public void mostrar() {
        if (cabeza == null) return;
        NodoCircular temp = cabeza;
        System.out.print("Lista circular: ");
        do {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        } while (temp != cabeza);
        System.out.println();
    }
}

public class Ejercicio5ListaCircular {
    public static void main(String[] args) {
        ListaCircular lista = new ListaCircular();
        lista.insertar(1);
        lista.insertar(2);
        lista.insertar(3);
        lista.mostrar();
        lista.eliminar(2);
        lista.mostrar();
    }
}
