class Lista3 {
    private Nodo cabeza;

    public void insertar(int dato) {
        Nodo nuevo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevo;
        }
    }

    public void eliminarEnPosicion(int posicion) {
        if (cabeza == null) {
            System.out.println("Lista vacía.");
            return;
        }
        if (posicion == 0) {
            cabeza = cabeza.siguiente;
            return;
        }
        Nodo temp = cabeza;
        for (int i = 0; temp != null && i < posicion - 1; i++) {
            temp = temp.siguiente;
        }
        if (temp == null || temp.siguiente == null) {
            System.out.println("Posición inválida.");
            return;
        }
        temp.siguiente = temp.siguiente.siguiente;
    }

    public void mostrar() {
        Nodo temp = cabeza;
        System.out.print("Lista: ");
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }
}

public class Ejercicio3EliminacionControlada {
    public static void main(String[] args) {
        Lista3 lista = new Lista3();
        lista.insertar(10);
        lista.insertar(20);
        lista.insertar(30);
        lista.mostrar();
        lista.eliminarEnPosicion(1);
        lista.mostrar();
    }
}
