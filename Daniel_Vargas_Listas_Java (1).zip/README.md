# Complejidad de Operaciones

| Ejercicio | Operación                 | Complejidad |
|-----------|--------------------------|-------------|
| 1         | Insertar al final         | O(n)        |
|           | Mostrar lista             | O(n)        |
| 2         | Insertar en posición      | O(n)        |
| 3         | Eliminar en posición      | O(n)        |
| 4         | Insertar (doble)          | O(n)        |
|           | Eliminar primero/último   | O(1) / O(n) |
| 5         | Insertar circular         | O(n)        |
|           | Eliminar circular         | O(n)        |
| 6         | Operaciones de cola       | O(1)        |
