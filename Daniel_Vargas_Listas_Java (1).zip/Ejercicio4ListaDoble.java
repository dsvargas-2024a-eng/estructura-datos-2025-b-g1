class NodoDoble {
    int dato;
    NodoDoble siguiente;
    NodoDoble anterior;

    NodoDoble(int dato) {
        this.dato = dato;
        this.siguiente = null;
        this.anterior = null;
    }
}

class ListaDoble {
    private NodoDoble cabeza;

    public void insertar(int dato) {
        NodoDoble nuevo = new NodoDoble(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoDoble temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevo;
            nuevo.anterior = temp;
        }
    }

    public void eliminarPrimero() {
        if (cabeza != null) {
            cabeza = cabeza.siguiente;
            if (cabeza != null) cabeza.anterior = null;
        }
    }

    public void eliminarUltimo() {
        if (cabeza == null) return;
        if (cabeza.siguiente == null) {
            cabeza = null;
            return;
        }
        NodoDoble temp = cabeza;
        while (temp.siguiente != null) {
            temp = temp.siguiente;
        }
        temp.anterior.siguiente = null;
    }

    public void mostrar() {
        NodoDoble temp = cabeza;
        System.out.print("Lista doble: ");
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }
}

public class Ejercicio4ListaDoble {
    public static void main(String[] args) {
        ListaDoble lista = new ListaDoble();
        lista.insertar(1);
        lista.insertar(2);
        lista.insertar(3);
        lista.mostrar();
        lista.eliminarPrimero();
        lista.mostrar();
        lista.eliminarUltimo();
        lista.mostrar();
    }
}
