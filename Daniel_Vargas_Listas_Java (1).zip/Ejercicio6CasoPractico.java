import java.util.LinkedList;
import java.util.Queue;

public class Ejercicio6CasoPractico {
    public static void main(String[] args) {
        Queue<String> colaPacientes = new LinkedList<>();

        colaPacientes.add("Paciente A");
        colaPacientes.add("Paciente B");
        colaPacientes.add("Paciente C");

        System.out.println("Pacientes en cola: " + colaPacientes);

        while (!colaPacientes.isEmpty()) {
            System.out.println("Atendiendo: " + colaPacientes.poll());
            System.out.println("Cola actual: " + colaPacientes);
        }
    }
}
