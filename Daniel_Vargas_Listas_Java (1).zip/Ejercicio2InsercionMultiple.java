import java.util.Scanner;

class Lista2 {
    private Nodo cabeza;

    public void insertarEnPosicion(int dato, int posicion) {
        Nodo nuevo = new Nodo(dato);
        if (posicion == 0) {
            nuevo.siguiente = cabeza;
            cabeza = nuevo;
            return;
        }
        Nodo temp = cabeza;
        for (int i = 0; temp != null && i < posicion - 1; i++) {
            temp = temp.siguiente;
        }
        if (temp == null) {
            System.out.println("Posición inválida.");
            return;
        }
        nuevo.siguiente = temp.siguiente;
        temp.siguiente = nuevo;
    }

    public void mostrar() {
        Nodo temp = cabeza;
        System.out.print("Lista: ");
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }
}

public class Ejercicio2InsercionMultiple {
    public static void main(String[] args) {
        Lista2 lista = new Lista2();
        Scanner sc = new Scanner(System.in);

        lista.insertarEnPosicion(10, 0);
        lista.insertarEnPosicion(20, 1);
        lista.insertarEnPosicion(15, 1);
        lista.mostrar();
    }
}
