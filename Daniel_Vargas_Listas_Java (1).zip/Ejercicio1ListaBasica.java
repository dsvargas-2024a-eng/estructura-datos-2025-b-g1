import java.util.Scanner;

class Nodo {
    int dato;
    Nodo siguiente;

    Nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}

class Lista {
    private Nodo cabeza;

    public void insertarAlFinal(int dato) {
        Nodo nuevo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevo;
        }
    }

    public void mostrar() {
        Nodo temp = cabeza;
        if (temp == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        System.out.print("Lista: ");
        while (temp != null) {
            System.out.print(temp.dato + " ");
            temp = temp.siguiente;
        }
        System.out.println();
    }
}

public class Ejercicio1ListaBasica {
    public static void main(String[] args) {
        Lista lista = new Lista();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("1. Insertar al final");
            System.out.println("2. Mostrar lista");
            System.out.println("0. Salir");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese número: ");
                    lista.insertarAlFinal(sc.nextInt());
                    break;
                case 2:
                    lista.mostrar();
                    break;
            }
        } while (opcion != 0);
    }
}
